#!/usr/bin/env bash
git clone https://github.com/ztombol/bats-assert
git clone https://github.com/ztombol/bats-support
